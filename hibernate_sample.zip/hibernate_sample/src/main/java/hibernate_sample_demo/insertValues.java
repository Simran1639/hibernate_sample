package hibernate_sample_demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class insertValues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory EMF=Persistence.createEntityManagerFactory("dev");
		EntityManager manager=EMF.createEntityManager();
		EntityTransaction et=manager.getTransaction();
		
		Student s=new Student();
		s.setId(1);
		s.setAge(23);
		s.setName("simran");
		
		Student s1=new Student();
		s1.setId(2);
		s1.setAge(26);
		s1.setName("pradeep");
		
		et.begin();
		manager.persist(s);
		manager.persist(s1);
		et.commit();

		
	}

}
