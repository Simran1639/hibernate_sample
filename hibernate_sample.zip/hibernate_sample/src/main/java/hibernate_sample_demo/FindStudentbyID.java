package hibernate_sample_demo;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FindStudentbyID {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("dev");
		EntityManager EM=factory.createEntityManager();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the id whose data you want????????");
		int id=sc.nextInt();
		
		Student s=EM.find(Student.class,id);
		System.out.println("student id:"+s.getId()+" student name:"+s.getName()+" student age:"+s.getAge());


	}

}
