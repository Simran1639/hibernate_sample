package hibernate_sample_demo;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class testConnection {

	public static void main(String[] args) {
		
EntityManagerFactory EMF=Persistence.createEntityManagerFactory("dev");
    System.out.println(EMF);
	}

}
